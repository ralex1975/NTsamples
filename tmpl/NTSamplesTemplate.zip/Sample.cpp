#include <Windows.h>
#include <stdio.h>

int wmain(int argc, wchar_t* argv[])
{
    printf("Sample app\n");
    return 0;
}
